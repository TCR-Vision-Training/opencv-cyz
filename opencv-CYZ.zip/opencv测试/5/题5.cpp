#include <opencv2/opencv.hpp>
#include <iostream>
#include <iomanip>
#include <filesystem>

using namespace cv;
using namespace std;

//------------------------------------------------
// 找齿轮
//------------------------------------------------
vector<vector<Point>> findGears(Mat img)
{
    Mat gray, binary;

    cvtColor(img,
             gray,
             COLOR_BGR2GRAY);

    threshold(gray,
              binary,
              180,
              255,
              THRESH_BINARY_INV);

    vector<vector<Point>> contours;

    findContours(binary,
                 contours,
                 RETR_EXTERNAL,
                 CHAIN_APPROX_NONE);

    vector<vector<Point>> gears;

    for (auto c : contours)
    {
        if (contourArea(c) > 5000)
            gears.push_back(c);
    }

    return gears;
}

//------------------------------------------------
// 轮廓缺口检测
//------------------------------------------------
int detectNotches(
    vector<Point> standard,
    vector<Point> sample,
    Mat &result)
{

    Moments m =
        moments(sample);

    Point center(
        m.m10 / m.m00,
        m.m01 / m.m00);

    vector<double> stdRadius;
    vector<double> samRadius;

    int angleStep = 2;

    for (int a = 0; a < 360; a += angleStep)
    {

        double rad =
            a * CV_PI / 180;

        double maxStd = 0;
        double maxSam = 0;

        for (auto p : standard)
        {

            double ang =
                atan2(
                    p.y - center.y,
                    p.x - center.x);

            double deg =
                ang * 180 / CV_PI;

            if (deg < 0)
                deg += 360;

            if (abs(deg - a) < 2)
            {

                double r =
                    norm(p - center);

                maxStd = max(maxStd, r);
            }
        }

        for (auto p : sample)
        {

            double ang =
                atan2(
                    p.y - center.y,
                    p.x - center.x);

            double deg =
                ang * 180 / CV_PI;

            if (deg < 0)
                deg += 360;

            if (abs(deg - a) < 2)
            {

                double r =
                    norm(p - center);

                maxSam = max(maxSam, r);
            }
        }

        stdRadius.push_back(maxStd);
        samRadius.push_back(maxSam);
    }

    //----------------------------
    // 寻找半径下降区域
    //----------------------------

    int count = 0;

    bool missing = false;

    for (int i = 0; i < stdRadius.size(); i++)
    {

        double diff =
            stdRadius[i] - samRadius[i];

        if (diff > 10)
        {

            if (!missing)
            {
                count++;
                missing = true;
            }
        }

        else
        {
            missing = false;
        }
    }

    //----------------------------
    // 显示
    //----------------------------

    if (count > 0)
    {

        Rect box =
            boundingRect(sample);

        rectangle(result,
                  box,
                  Scalar(0, 0, 255),
                  3);

        putText(result,
                "MISSING",
                box.tl(),
                FONT_HERSHEY_SIMPLEX,
                0.7,
                Scalar(0, 0, 255),
                2);
    }

    return count;
}

int main(int argc, char **argv)
{
    namespace fs = std::filesystem;

    string imagePath = (argc > 1) ? argv[1] : "input.png";

    fs::path inputPath(imagePath);
    vector<fs::path> searchPaths;

    if (inputPath.is_absolute())
    {
        searchPaths.push_back(inputPath);
    }
    else
    {
        searchPaths.push_back(fs::current_path() / inputPath);
        searchPaths.push_back(fs::path(__FILE__).parent_path() / inputPath);

        if (argc > 0 && argv[0] != nullptr)
        {
            fs::path exePath(argv[0]);
            if (exePath.is_relative())
            {
                exePath = fs::current_path() / exePath;
            }

            if (exePath.has_parent_path())
            {
                searchPaths.push_back(exePath.parent_path() / inputPath);
            }
        }
    }

    fs::path resolvedInput;
    for (const auto &p : searchPaths)
    {
        if (fs::exists(p))
        {
            resolvedInput = p;
            break;
        }
    }

    if (resolvedInput.empty())
    {
        resolvedInput = searchPaths.front();
    }

    Mat img =
        imread(resolvedInput.string());

    if (img.empty())
    {
        cout << "读取失败" << endl;
        cout << "尝试路径: " << resolvedInput.string() << endl;
        return -1;
    }

    Mat result = img.clone();

    vector<vector<Point>> gears =
        findGears(img);

    cout << "齿轮数量:"
         << gears.size()
         << endl;

    // 寻找左侧标准件

    int standardID = 0;

    int minX = 99999;

    for (int i = 0; i < gears.size(); i++)
    {

        Moments m =
            moments(gears[i]);

        int x = m.m10 / m.m00;

        if (x < minX)
        {
            minX = x;
            standardID = i;
        }
    }

    vector<Point> standard =
        gears[standardID];

    int id = 0;

    for (int i = 0; i < gears.size(); i++)
    {

        if (i == standardID)
            continue;

        id++;

        double score =
            matchShapes(
                standard,
                gears[i],
                CONTOURS_MATCH_I1,
                0);

        double similarity =
            (1 - score) * 100;

        int missing =
            detectNotches(
                standard,
                gears[i],
                result);

        if (id == 1)
            cout << "齿轮A:" << endl;
        else
            cout << "齿轮B:" << endl;

        cout << "轮廓相似度:"
             << fixed
             << setprecision(2)
             << similarity
             << "%" << endl;

        cout << "缺齿数量:"
             << missing
             << endl;

        cout << "----------------" << endl;
    }

    namedWindow("Result", WINDOW_NORMAL);
    imshow("Result", result);
    waitKey(0);
    destroyAllWindows();

    return 0;
}
