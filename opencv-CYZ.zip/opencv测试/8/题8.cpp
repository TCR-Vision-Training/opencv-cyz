#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <filesystem>

using namespace cv;
using namespace std;

int main(int argc, char **argv)
{
    namespace fs = std::filesystem;

    string imagePath = (argc > 1) ? argv[1] : "input.png";
    fs::path inputPath(imagePath);
    vector<fs::path> searchPaths;

    if (inputPath.is_absolute())
    {
        searchPaths.push_back(inputPath);
    }
    else
    {
        searchPaths.push_back(fs::current_path() / inputPath);
        searchPaths.push_back(fs::path(__FILE__).parent_path() / inputPath);

        if (argc > 0 && argv[0] != nullptr)
        {
            fs::path exePath(argv[0]);
            if (exePath.is_relative())
            {
                exePath = fs::current_path() / exePath;
            }
            if (exePath.has_parent_path())
            {
                searchPaths.push_back(exePath.parent_path() / inputPath);
            }
        }
    }

    fs::path resolvedInput;
    for (const auto &p : searchPaths)
    {
        if (fs::exists(p))
        {
            resolvedInput = p;
            break;
        }
    }

    if (resolvedInput.empty())
    {
        resolvedInput = searchPaths.front();
    }

    Mat src = imread(resolvedInput.string());
    if (src.empty())
    {
        cerr << "错误：无法读取图像 " << resolvedInput.string() << endl;
        return -1;
    }

    int totalPixels = src.cols * src.rows;
    cout << "图像尺寸: " << src.cols << " x " << src.rows << endl;
    cout << "总像素: " << totalPixels << endl;

    // 2. 转HSV
    Mat hsv;
    cvtColor(src, hsv, COLOR_BGR2HSV);

    // 3. 提取掩码
    Mat maskRed1, maskRed2, maskRed;
    inRange(hsv, Scalar(0, 80, 80), Scalar(10, 255, 255), maskRed1);
    inRange(hsv, Scalar(170, 80, 80), Scalar(180, 255, 255), maskRed2);
    bitwise_or(maskRed1, maskRed2, maskRed);

    Mat maskGreen;
    inRange(hsv, Scalar(35, 80, 80), Scalar(85, 255, 255), maskGreen);

    Mat maskBlue;
    inRange(hsv, Scalar(100, 80, 80), Scalar(130, 255, 255), maskBlue);

    Mat maskYellow;
    inRange(hsv, Scalar(20, 80, 80), Scalar(40, 255, 255), maskYellow);

    Mat maskPurple;
    inRange(hsv, Scalar(130, 50, 50), Scalar(165, 255, 255), maskPurple);

    // 4. 形态学优化
    Mat kernel = getStructuringElement(MORPH_ELLIPSE, Size(5, 5));

    morphologyEx(maskRed, maskRed, MORPH_CLOSE, kernel, Point(-1, -1), 2);
    morphologyEx(maskRed, maskRed, MORPH_OPEN, kernel, Point(-1, -1), 1);
    morphologyEx(maskGreen, maskGreen, MORPH_CLOSE, kernel, Point(-1, -1), 2);
    morphologyEx(maskGreen, maskGreen, MORPH_OPEN, kernel, Point(-1, -1), 1);
    morphologyEx(maskBlue, maskBlue, MORPH_CLOSE, kernel, Point(-1, -1), 2);
    morphologyEx(maskBlue, maskBlue, MORPH_OPEN, kernel, Point(-1, -1), 1);
    morphologyEx(maskYellow, maskYellow, MORPH_CLOSE, kernel, Point(-1, -1), 2);
    morphologyEx(maskYellow, maskYellow, MORPH_OPEN, kernel, Point(-1, -1), 1);
    morphologyEx(maskPurple, maskPurple, MORPH_CLOSE, kernel, Point(-1, -1), 2);
    morphologyEx(maskPurple, maskPurple, MORPH_OPEN, kernel, Point(-1, -1), 1);

    // 5. 统计面积
    int aR = countNonZero(maskRed);
    int aG = countNonZero(maskGreen);
    int aB = countNonZero(maskBlue);
    int aY = countNonZero(maskYellow);
    int aP = countNonZero(maskPurple);

    double pR = (double)aR / totalPixels * 100;
    double pG = (double)aG / totalPixels * 100;
    double pB = (double)aB / totalPixels * 100;
    double pY = (double)aY / totalPixels * 100;
    double pP = (double)aP / totalPixels * 100;

    // 控制台输出（按面积从大到小排序）
    vector<pair<string, pair<int, double>>> sorted;
    sorted.push_back({"蓝色 (Blue)", {aB, pB}});
    sorted.push_back({"紫色 (Purple)", {aP, pP}});
    sorted.push_back({"黄色 (Yellow)", {aY, pY}});
    sorted.push_back({"红色 (Red)", {aR, pR}});
    sorted.push_back({"绿色 (Green)", {aG, pG}});

    sort(sorted.begin(), sorted.end(),
         [](const pair<string, pair<int, double>> &a, const pair<string, pair<int, double>> &b)
         {
             return a.second.first > b.second.first;
         });

    cout << "\n===== 颜色区域面积统计（从大到小）=====" << endl;
    cout << left << setw(20) << "颜色"
         << right << setw(12) << "像素面积"
         << setw(14) << "占比(%)" << endl;
    cout << "-----------------------------------------------" << endl;
    for (const auto &c : sorted)
    {
        cout << left << setw(20) << c.first
             << right << setw(12) << c.second.first
             << setw(12) << fixed << setprecision(2) << c.second.second << "%" << endl;
    }
    cout << "-----------------------------------------------" << endl;

    vector<Mat> masks = {maskBlue, maskPurple, maskYellow, maskRed, maskGreen};
    vector<string> labels = {"Blue", "Purple", "Yellow", "Red", "Green"};
    vector<Scalar> colors = {
        Scalar(255, 0, 0),
        Scalar(255, 0, 255),
        Scalar(0, 255, 255),
        Scalar(0, 0, 255),
        Scalar(0, 255, 0)};

    for (size_t i = 0; i < masks.size(); ++i)
    {
        Mat binary = Mat::zeros(src.size(), CV_8UC1);
        binary.setTo(255, masks[i]);
        string outName = labels[i] + "_binary.png";
        imwrite(outName, binary);
        cout << "已保存二值图: " << outName << endl;
    }

    Mat result = src.clone();
    for (size_t i = 0; i < masks.size(); ++i)
    {
        Mat overlay = Mat::zeros(src.size(), CV_8UC3);
        overlay.setTo(colors[i], masks[i]);
        addWeighted(result, 0.6, overlay, 0.4, 0.0, result);
    }

    putText(result, "Color Area Analysis", Point(10, 30), FONT_HERSHEY_SIMPLEX, 0.8, Scalar(0, 255, 0), 2, LINE_AA);

    namedWindow("Result", WINDOW_NORMAL);
    imshow("Result", result);
    waitKey(0);
    destroyAllWindows();

    return 0;
}
