#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <filesystem>

using namespace cv;
using namespace std;

// ==================== 缺陷结构体 ====================
struct Defect
{
    Rect bbox;
    string type; // "Scratch" / "Dark Spot" / "Bright Spot"
    string label;
    double area;
    double aspectRatio;
    double meanGray;
};

// ==================== 工具函数 ====================
Mat createMaskFromContour(const vector<Point> &contour, Size size)
{
    Mat mask = Mat::zeros(size, CV_8UC1);
    drawContours(mask, vector<vector<Point>>{contour}, -1, Scalar(255), FILLED);
    return mask;
}

// 计算两个矩形之间的IoU
double computeIoU(const Rect &a, const Rect &b)
{
    Rect inter = a & b;
    double interArea = inter.area();
    double unionArea = a.area() + b.area() - interArea;
    return (unionArea > 0) ? interArea / unionArea : 0;
}

// ==================== 主函数 ====================
int main(int argc, char **argv)
{
    namespace fs = std::filesystem;

    // ========== 1. 读取图像 ==========
    string imgPath = (argc > 1) ? argv[1] : "input.png";

    fs::path inputPath(imgPath);
    vector<fs::path> searchPaths;

    if (inputPath.is_absolute())
    {
        searchPaths.push_back(inputPath);
    }
    else
    {
        searchPaths.push_back(fs::current_path() / inputPath);
        searchPaths.push_back(fs::path(__FILE__).parent_path() / inputPath);

        if (argc > 0 && argv[0] != nullptr)
        {
            fs::path exePath(argv[0]);
            if (exePath.is_relative())
            {
                exePath = fs::current_path() / exePath;
            }

            if (exePath.has_parent_path())
            {
                searchPaths.push_back(exePath.parent_path() / inputPath);
            }
        }
    }

    fs::path resolvedInput;
    for (const auto &p : searchPaths)
    {
        if (fs::exists(p))
        {
            resolvedInput = p;
            break;
        }
    }

    if (resolvedInput.empty())
    {
        resolvedInput = searchPaths.front();
    }

    Mat src = imread(resolvedInput.string());
    if (src.empty())
    {
        cerr << "错误：无法加载图像 '" << resolvedInput.string() << "'" << endl;
        return -1;
    }

    Mat gray;
    cvtColor(src, gray, COLOR_BGR2GRAY);
    int rows = gray.rows, cols = gray.cols;

    // ========== 2. 创建边缘掩膜，排除边缘区域 ==========
    //    边缘15像素内不参与检测，避免边界伪缺陷
    int borderWidth = 15;
    Mat edgeMask = Mat::zeros(rows, cols, CV_8UC1);
    rectangle(edgeMask, Point(borderWidth, borderWidth),
              Point(cols - borderWidth, rows - borderWidth),
              Scalar(255), FILLED);

    // ========== 3. 估计局部背景 ==========
    Mat background;
    GaussianBlur(gray, background, Size(51, 51), 0);

    // ========== 4. 计算差异图 ==========
    Mat diff_dark, diff_bright;
    subtract(background, gray, diff_dark);
    subtract(gray, background, diff_bright);

    // ========== 5. 检测暗色缺陷（划痕 + 暗斑）==========
    Mat darkMask;
    threshold(diff_dark, darkMask, 25, 255, THRESH_BINARY);

    // 应用边缘掩膜：去除边缘区域的误检
    bitwise_and(darkMask, edgeMask, darkMask);

    // 形态学开运算：去除小噪点
    Mat kernelOpen = getStructuringElement(MORPH_ELLIPSE, Size(3, 3));
    morphologyEx(darkMask, darkMask, MORPH_OPEN, kernelOpen);

    // ========== 6. 检测亮色缺陷 ==========
    Mat brightMask;
    threshold(diff_bright, brightMask, 30, 255, THRESH_BINARY);
    bitwise_and(brightMask, edgeMask, brightMask);
    morphologyEx(brightMask, brightMask, MORPH_OPEN, kernelOpen);

    // ========== 7. 查找轮廓 ==========
    vector<vector<Point>> darkContours, brightContours;
    findContours(darkMask.clone(), darkContours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
    findContours(brightMask.clone(), brightContours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

    // ========== 8. 分类暗色缺陷 ==========
    vector<Defect> defects;
    int id = 1;

    for (const auto &contour : darkContours)
    {
        double area = contourArea(contour);

        // ★ 提高面积阈值，过滤噪声碎片
        if (area < 50)
            continue;

        // 计算最小外接旋转矩形
        RotatedRect rrect = minAreaRect(contour);
        float w = rrect.size.width;
        float h = rrect.size.height;
        float maxDim = max(w, h);
        float minDim = min(w, h) + 1e-5f;
        float ar = maxDim / minDim;

        Rect bbox = boundingRect(contour);
        bbox &= Rect(0, 0, cols, rows);

        Mat mask = createMaskFromContour(contour, gray.size());
        double meanGray = mean(gray, mask)[0];

        Defect d;
        d.bbox = bbox;
        d.area = area;
        d.aspectRatio = ar;
        d.meanGray = meanGray;

        if (ar > 5.0 && minDim < 25)
        {
            // ★ 划痕：细长轮廓，长宽比 > 5
            d.type = "Scratch";
            d.label = "D" + to_string(id++);
            defects.push_back(d);
        }
        else if (area >= 80)
        {
            // ★ 暗斑：面积较大，近似圆形
            d.type = "Dark Spot";
            d.label = "D" + to_string(id++);
            defects.push_back(d);
        }
    }

    // ========== 9. 分类亮色缺陷 ==========
    for (const auto &contour : brightContours)
    {
        double area = contourArea(contour);
        if (area < 25)
            continue;

        Rect bbox = boundingRect(contour);
        bbox &= Rect(0, 0, cols, rows);

        Mat mask = createMaskFromContour(contour, gray.size());
        double meanGray = mean(gray, mask)[0];

        Defect d;
        d.bbox = bbox;
        d.area = area;
        d.aspectRatio = 1.0;
        d.meanGray = meanGray;
        d.type = "Bright Spot";
        d.label = "D" + to_string(id++);
        defects.push_back(d);
    }

    // ========== 10. ★ 合并重叠/相邻的检测结果 ==========
    //    IoU > 0.3 的框只保留面积最大的那个
    vector<bool> removed(defects.size(), false);
    for (size_t i = 0; i < defects.size(); i++)
    {
        if (removed[i])
            continue;
        for (size_t j = i + 1; j < defects.size(); j++)
        {
            if (removed[j])
                continue;
            double iou = computeIoU(defects[i].bbox, defects[j].bbox);
            if (iou > 0.3)
            {
                // 保留面积更大的，删除面积更小的
                if (defects[i].area >= defects[j].area)
                    removed[j] = true;
                else
                    removed[i] = true;
            }
        }
    }

    // 移除被标记的缺陷，重新编号
    vector<Defect> finalDefects;
    int newId = 1;
    for (size_t i = 0; i < defects.size(); i++)
    {
        if (!removed[i])
        {
            defects[i].label = "D" + to_string(newId++);
            finalDefects.push_back(defects[i]);
        }
    }
    defects = finalDefects;

    // ========== 11. 控制台输出统计 ==========
    int nScratch = 0, nDarkSpot = 0, nBrightSpot = 0;
    for (const auto &d : defects)
    {
        if (d.type == "Scratch")
            nScratch++;
        else if (d.type == "Dark Spot")
            nDarkSpot++;
        else if (d.type == "Bright Spot")
            nBrightSpot++;
    }

    cout << "====================================" << endl;
    cout << "      表面缺陷检测结果               " << endl;
    cout << "====================================" << endl;
    cout << "划痕     : " << nScratch << " 条" << endl;
    cout << "暗斑     : " << nDarkSpot << " 处" << endl;
    cout << "亮点     : " << nBrightSpot << " 处" << endl;
    cout << "------------------------------------" << endl;
    cout << "总缺陷数 : " << defects.size() << endl;
    cout << "====================================" << endl;

    for (const auto &d : defects)
    {
        cout << "  " << d.label << " [" << d.type << "]"
             << "  位置=(" << d.bbox.x << "," << d.bbox.y
             << "," << d.bbox.width << "," << d.bbox.height << ")"
             << "  面积=" << (int)d.area
             << "  长宽比=" << fixed << setprecision(1) << d.aspectRatio
             << "  平均灰度=" << (int)d.meanGray
             << endl;
    }

    // ========== 12. 在原图上绘制标注 ==========
    Mat result = src.clone();

    // 标题文字（加白色底衬，避免文字重叠混乱）
    string title = "Total Defects: " + to_string(defects.size());
    int baseline = 0;
    Size textSize = getTextSize(title, FONT_HERSHEY_SIMPLEX, 0.9, 2, &baseline);
    rectangle(result, Point(5, 5), Point(textSize.width + 15, textSize.height + 15),
              Scalar(0, 0, 0), FILLED);
    putText(result, title,
            Point(10, textSize.height + 8),
            FONT_HERSHEY_SIMPLEX, 0.9,
            Scalar(0, 0, 255), 2);

    for (const auto &d : defects)
    {
        // 红色矩形框
        rectangle(result, d.bbox, Scalar(0, 0, 255), 2);

        // 编号标签（带黑色背景，避免与划痕重叠看不清）
        string labelText = d.label;
        int lx = d.bbox.x;
        int ly = max(d.bbox.y - 8, 20);
        Size ls = getTextSize(labelText, FONT_HERSHEY_SIMPLEX, 0.6, 2, &baseline);
        rectangle(result, Point(lx - 1, ly - ls.height - 3),
                  Point(lx + ls.width + 3, ly + 3),
                  Scalar(0, 0, 0), FILLED);
        putText(result, labelText,
                Point(lx, ly),
                FONT_HERSHEY_SIMPLEX, 0.6,
                Scalar(0, 0, 255), 2);
    }

    namedWindow("Result", WINDOW_NORMAL);
    imshow("Result", result);
    waitKey(0);
    destroyAllWindows();

    return 0;
}
