#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>
#include <cmath>
#include <filesystem>

int main(int argc, char **argv)
{
    namespace fs = std::filesystem;

    std::string imagePath = (argc > 1) ? argv[1] : "input.png";
    fs::path inputPath(imagePath);
    std::vector<fs::path> searchPaths;

    if (inputPath.is_absolute())
    {
        searchPaths.push_back(inputPath);
    }
    else
    {
        searchPaths.push_back(fs::current_path() / inputPath);
        searchPaths.push_back(fs::path(__FILE__).parent_path() / inputPath);

        if (argc > 0 && argv[0] != nullptr)
        {
            fs::path exePath(argv[0]);
            if (exePath.is_relative())
            {
                exePath = fs::current_path() / exePath;
            }
            if (exePath.has_parent_path())
            {
                searchPaths.push_back(exePath.parent_path() / inputPath);
            }
        }
    }

    fs::path resolvedInput;
    for (const auto &p : searchPaths)
    {
        if (fs::exists(p))
        {
            resolvedInput = p;
            break;
        }
    }

    if (resolvedInput.empty())
    {
        resolvedInput = searchPaths.front();
    }

    cv::Mat src = cv::imread(resolvedInput.string());
    if (src.empty())
    {
        std::cerr << "[ERROR] 无法加载图像 " << resolvedInput.string() << std::endl;
        return -1;
    }

    cv::Mat gray;
    cv::cvtColor(src, gray, cv::COLOR_BGR2GRAY);

    // ========== 过滤干扰物 ==========
    cv::Mat hsv;
    cv::cvtColor(src, hsv, cv::COLOR_BGR2HSV);

    cv::Mat greenMask, redMask1, redMask2, redMask;
    cv::inRange(hsv, cv::Scalar(35, 100, 100), cv::Scalar(85, 255, 255), greenMask);
    cv::dilate(greenMask, greenMask, cv::Mat(), cv::Point(-1, -1), 5);

    cv::inRange(hsv, cv::Scalar(0, 100, 100), cv::Scalar(10, 255, 255), redMask1);
    cv::inRange(hsv, cv::Scalar(160, 100, 100), cv::Scalar(180, 255, 255), redMask2);
    redMask = redMask1 | redMask2;
    cv::dilate(redMask, redMask, cv::Mat(), cv::Point(-1, -1), 5);

    cv::Mat interfMask = greenMask | redMask;

    cv::Mat cleaned = src.clone();
    cleaned.setTo(cv::Scalar(255, 255, 255), interfMask);

    // ========== 预处理 ==========
    cv::Mat grayClean, blurred;
    cv::cvtColor(cleaned, grayClean, cv::COLOR_BGR2GRAY);
    cv::GaussianBlur(grayClean, blurred, cv::Size(5, 5), 1.0);

    // ========== 角点检测 ==========
    cv::Size patternSize(12, 8);
    std::vector<cv::Point2f> corners;
    int flags = cv::CALIB_CB_ADAPTIVE_THRESH | cv::CALIB_CB_NORMALIZE_IMAGE | cv::CALIB_CB_FAST_CHECK;

    bool found = cv::findChessboardCorners(blurred, patternSize, corners, flags);
    if (!found)
        found = cv::findChessboardCorners(gray, patternSize, corners, flags);
    if (!found)
        found = cv::findChessboardCorners(blurred, patternSize, corners, flags & ~cv::CALIB_CB_FAST_CHECK);

    if (!found || corners.empty())
    {
        std::cerr << "[ERROR] 未检测到棋盘格角点!" << std::endl;
        return -1;
    }

    // ========== 亚像素精化 ==========
    cv::cornerSubPix(gray, corners, cv::Size(11, 11), cv::Size(-1, -1),
                     cv::TermCriteria(cv::TermCriteria::EPS + cv::TermCriteria::MAX_ITER, 30, 0.001));

    // ========== 角点数量 ==========
    int detected = (int)corners.size();
    int expected = patternSize.width * patternSize.height;

    // ========== 方格像素尺寸 ==========
    double sumW = 0.0, sumH = 0.0;
    int cntW = 0, cntH = 0;

    for (int r = 0; r < patternSize.height; r++)
        for (int c = 0; c < patternSize.width - 1; c++)
        {
            int idx = r * patternSize.width + c;
            double dx = corners[idx + 1].x - corners[idx].x;
            double dy = corners[idx + 1].y - corners[idx].y;
            sumW += std::sqrt(dx * dx + dy * dy);
            cntW++;
        }

    for (int r = 0; r < patternSize.height - 1; r++)
        for (int c = 0; c < patternSize.width; c++)
        {
            int idx = r * patternSize.width + c;
            double dx = corners[idx + patternSize.width].x - corners[idx].x;
            double dy = corners[idx + patternSize.width].y - corners[idx].y;
            sumH += std::sqrt(dx * dx + dy * dy);
            cntH++;
        }

    double avgW = (cntW > 0) ? sumW / cntW : 0;
    double avgH = (cntH > 0) ? sumH / cntH : 0;
    double avgPx = (avgW + avgH) / 2.0;
    double pxPerMm = avgPx / 5.0;

    // ========== 控制台输出结果 ==========
    std::cout << "========================================" << std::endl;
    std::cout << "  棋盘格角点检测与尺寸标定 结果" << std::endl;
    std::cout << "========================================" << std::endl;
    std::cout << "内角点数量:      " << detected << " / " << expected
              << " ((9-1)x(13-1) = 8x12)" << std::endl;
    std::cout << "方格像素尺寸:    ~" << (int)avgW << " x " << (int)avgH << " px" << std::endl;
    std::cout << "像素-物理比例:   " << pxPerMm << " px/mm  (" << (int)avgPx << "px / 5mm)" << std::endl;
    std::cout << "========================================" << std::endl;

    // ========== 最终结果图 ==========
    cv::Mat finalImg = src.clone();
    cv::drawChessboardCorners(finalImg, patternSize, cv::Mat(corners), found);

    for (size_t i = 0; i < corners.size(); i++)
        cv::circle(finalImg, corners[i], 2, cv::Scalar(0, 0, 255), -1);

    std::string txt1 = "Corners: " + std::to_string(detected) + " (expected: " + std::to_string(expected) + ")";
    std::string txt2 = "Square: ~" + std::to_string((int)avgW) + "x" + std::to_string((int)avgH) + " px";
    std::string txt3 = "Ratio: ~" + std::to_string((int)pxPerMm) + " px/mm";

    cv::putText(finalImg, txt1, cv::Point(10, 25), cv::FONT_HERSHEY_SIMPLEX, 0.55, cv::Scalar(0, 0, 0), 4, cv::LINE_AA);
    cv::putText(finalImg, txt1, cv::Point(10, 25), cv::FONT_HERSHEY_SIMPLEX, 0.55, cv::Scalar(0, 0, 255), 2, cv::LINE_AA);
    cv::putText(finalImg, txt2, cv::Point(10, 50), cv::FONT_HERSHEY_SIMPLEX, 0.55, cv::Scalar(0, 0, 0), 4, cv::LINE_AA);
    cv::putText(finalImg, txt2, cv::Point(10, 50), cv::FONT_HERSHEY_SIMPLEX, 0.55, cv::Scalar(255, 200, 0), 2, cv::LINE_AA);
    cv::putText(finalImg, txt3, cv::Point(10, 75), cv::FONT_HERSHEY_SIMPLEX, 0.55, cv::Scalar(0, 0, 0), 4, cv::LINE_AA);
    cv::putText(finalImg, txt3, cv::Point(10, 75), cv::FONT_HERSHEY_SIMPLEX, 0.55, cv::Scalar(0, 255, 0), 2, cv::LINE_AA);

    cv::namedWindow("Result", cv::WINDOW_NORMAL);
    cv::imshow("Result", finalImg);
    cv::waitKey(0);
    cv::destroyAllWindows();

    return 0;
}
