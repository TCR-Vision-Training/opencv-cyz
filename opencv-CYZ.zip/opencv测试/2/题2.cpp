#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>
#include <string>
#include <filesystem>

using namespace cv;
using namespace std;

int main(int argc, char **argv)
{
    namespace fs = std::filesystem;

    string imagePath = (argc > 1) ? argv[1] : "input.png";

    fs::path inputPath(imagePath);
    vector<fs::path> searchPaths;

    if (inputPath.is_absolute())
    {
        searchPaths.push_back(inputPath);
    }
    else
    {
        searchPaths.push_back(fs::current_path() / inputPath);
        searchPaths.push_back(fs::path(__FILE__).parent_path() / inputPath);

        if (argc > 0 && argv[0] != nullptr)
        {
            fs::path exePath(argv[0]);
            if (exePath.is_relative())
            {
                exePath = fs::current_path() / exePath;
            }

            if (exePath.has_parent_path())
            {
                searchPaths.push_back(exePath.parent_path() / inputPath);
            }
        }
    }

    fs::path resolvedInput;
    for (const auto &p : searchPaths)
    {
        if (fs::exists(p))
        {
            resolvedInput = p;
            break;
        }
    }

    if (resolvedInput.empty())
    {
        resolvedInput = searchPaths.front();
    }

    Mat src = imread(resolvedInput.string());

    if (src.empty())
    {
        cout << "图片读取失败!" << endl;
        cout << "尝试路径: " << resolvedInput.string() << endl;
        return -1;
    }

    Mat gray;

    // 灰度化
    cvtColor(
        src,
        gray,
        COLOR_BGR2GRAY);

    // 增强对比度

    Mat enhance;

    equalizeHist(
        gray,
        enhance);

    // 滤波

    GaussianBlur(
        enhance,
        enhance,
        Size(7, 7),
        1.5);

    vector<Vec3f> circles;

    // 霍夫圆检测

    HoughCircles(
        enhance,
        circles,
        HOUGH_GRADIENT,
        1,
        55, // 圆之间最小距离
        100,
        22, // 降低阈值，提高检测率
        18,
        65);

    // 去除重复圆

    vector<Vec3f> result;

    for (auto c : circles)
    {

        bool same = false;

        for (auto old : result)
        {

            double d = sqrt(
                pow(c[0] - old[0], 2) +
                pow(c[1] - old[1], 2));

            if (d < 35)
            {
                same = true;
                break;
            }
        }

        if (!same)
            result.push_back(c);
    }

    int one = 0;
    int five = 0;
    int onej = 0;

    double money = 0;

    for (auto c : result)
    {

        int x = cvRound(c[0]);
        int y = cvRound(c[1]);
        int r = cvRound(c[2]);

        // 输出检测半径

        cout << "检测半径:" << r << endl;

        Scalar color;
        string name;

        /*
            半径分类

            1元 约50
            5角 约38
            1角 约26

        */

        if (r >= 43)
        {

            one++;

            money += 1.0;

            color = Scalar(0, 0, 255);

            name = "1元";
        }

        else if (r >= 31)
        {

            five++;

            money += 0.5;

            color = Scalar(0, 255, 0);

            name = "5角";
        }

        else if (r >= 20)
        {

            onej++;

            money += 0.1;

            color = Scalar(255, 0, 0);

            name = "1角";
        }

        else
        {

            continue;
        }

        // 画圆

        circle(
            src,
            Point(x, y),
            r,
            color,
            3);

        // 圆心

        circle(
            src,
            Point(x, y),
            3,
            color,
            -1);

        putText(
            src,
            name,
            Point(
                x - 20,
                y - r - 5),
            FONT_HERSHEY_SIMPLEX,
            0.8,
            color,
            2);
    }

    string info =
        "1:" + to_string(one) + " 5:" + to_string(five) + " 1j:" + to_string(onej) + " Total:" + to_string(one + five + onej);

    putText(
        src,
        info,
        Point(20, 40),
        FONT_HERSHEY_SIMPLEX,
        1,
        Scalar(0, 0, 0),
        2);

    cout << "================" << endl;

    cout << "1元数量:" << one << endl;
    cout << "5角数量:" << five << endl;
    cout << "1角数量:" << onej << endl;

    cout << "总金额:"
         << money
         << "元" << endl;

    namedWindow("Result", WINDOW_NORMAL);
    imshow("Result", src);
    waitKey(0);
    destroyAllWindows();

    return 0;
}
