#include <opencv2/opencv.hpp>
#include <vector>
#include <iostream>
#include <string>
#include <cmath>
#include <filesystem>

using namespace cv;
using namespace std;

struct ColorCfg
{
    Scalar lo1, hi1, lo2, hi2;
    bool dual;
};

vector<Point2f> getPoints(const Mat &mask)
{
    vector<Point2f> pts;
    for (int y = 0; y < mask.rows; y++)
        for (int x = 0; x < mask.cols; x++)
            if (mask.at<uchar>(y, x) > 0)
                pts.push_back(Point2f((float)x, (float)y));
    for (size_t i = 0; i < pts.size(); i++)
        for (size_t j = i + 1; j < pts.size(); j++)
            if (pts[j].x < pts[i].x)
            {
                Point2f t = pts[i];
                pts[i] = pts[j];
                pts[j] = t;
            }
    return pts;
}

double trajLength(const vector<Point2f> &pts)
{
    double len = 0;
    for (size_t i = 1; i < pts.size(); i++)
    {
        double dx = pts[i].x - pts[i - 1].x, dy = pts[i].y - pts[i - 1].y;
        len += sqrt(dx * dx + dy * dy);
    }
    return len;
}

double fitLinear(const vector<Point2f> &pts, double &a, double &b)
{
    int n = (int)pts.size();
    double sx = 0, sy = 0, sxy = 0, sx2 = 0;
    for (int i = 0; i < n; i++)
    {
        sx += pts[i].x;
        sy += pts[i].y;
        sxy += pts[i].x * pts[i].y;
        sx2 += pts[i].x * pts[i].x;
    }
    double den = n * sx2 - sx * sx;
    if (fabs(den) < 1e-10)
    {
        a = 0;
        b = sy / n;
        return 1e10;
    }
    a = (n * sxy - sx * sy) / den;
    b = (sy * sx2 - sx * sxy) / den;
    double res = 0;
    for (int i = 0; i < n; i++)
    {
        double e = pts[i].y - (a * pts[i].x + b);
        res += e * e;
    }
    return res / n;
}

double fitParabola(const vector<Point2f> &pts, double &a, double &b, double &c)
{
    int n = (int)pts.size();
    if (n < 3)
    {
        a = b = c = 0;
        return 1e10;
    }
    Mat A(n, 3, CV_64F), Y(n, 1, CV_64F);
    for (int i = 0; i < n; i++)
    {
        A.at<double>(i, 0) = pts[i].x * pts[i].x;
        A.at<double>(i, 1) = pts[i].x;
        A.at<double>(i, 2) = 1.0;
        Y.at<double>(i, 0) = pts[i].y;
    }
    Mat co;
    solve(A, Y, co, DECOMP_SVD);
    a = co.at<double>(0, 0);
    b = co.at<double>(1, 0);
    c = co.at<double>(2, 0);
    double res = 0;
    for (int i = 0; i < n; i++)
    {
        double e = pts[i].y - (a * pts[i].x * pts[i].x + b * pts[i].x + c);
        res += e * e;
    }
    return res / n;
}

double fitSin(const vector<Point2f> &pts, double &A, double &w, double &phi, double &off)
{
    int n = (int)pts.size();
    if (n < 10)
    {
        A = w = phi = off = 0;
        return 1e10;
    }
    double yMin = 1e9, yMax = -1e9;
    for (int i = 0; i < n; i++)
    {
        if (pts[i].y < yMin)
            yMin = pts[i].y;
        if (pts[i].y > yMax)
            yMax = pts[i].y;
    }
    off = (yMax + yMin) / 2.0;
    A = (yMax - yMin) / 2.0;
    if (A < 3.0)
    {
        A = 0;
        return 1e10;
    }
    vector<int> peaks, troughs;
    for (int i = 2; i < n - 2; i++)
    {
        double cy = pts[i].y;
        if (cy > pts[i - 1].y && cy > pts[i + 1].y && cy > pts[i - 2].y && cy > pts[i + 2].y)
            peaks.push_back(i);
        if (cy < pts[i - 1].y && cy < pts[i + 1].y && cy < pts[i - 2].y && cy < pts[i + 2].y)
            troughs.push_back(i);
    }
    w = 0.1;
    phi = 0;
    double period = 0;
    int cnt = 0;
    for (size_t i = 1; i < peaks.size(); i++)
    {
        period += pts[peaks[i]].x - pts[peaks[i - 1]].x;
        cnt++;
    }
    for (size_t i = 1; i < troughs.size(); i++)
    {
        period += pts[troughs[i]].x - pts[troughs[i - 1]].x;
        cnt++;
    }
    if (cnt > 0)
    {
        period /= cnt;
        if (period > 0.1)
            w = 2.0 * CV_PI / period;
    }
    if (!peaks.empty())
        phi = CV_PI / 2.0 - w * pts[peaks[0]].x;
    double res = 0;
    for (int i = 0; i < n; i++)
    {
        double e = pts[i].y - (A * sin(w * pts[i].x + phi) + off);
        res += e * e;
    }
    return res / n;
}

string analyze(const vector<Point2f> &pts, double &length, int colorCode)
{
    length = trajLength(pts);
    if (pts.size() < 3)
        return "unknown";
    double la, lb, pa, pb, pc, sa, sw, sp, so;
    double rLin = fitLinear(pts, la, lb);
    double rPar = fitParabola(pts, pa, pb, pc);
    double rSin = fitSin(pts, sa, sw, sp, so);
    cout << "  残差: 线性=" << rLin << " 抛物线=" << rPar << " 正弦=" << rSin << endl;
    double ymin = 1e9, ymax = -1e9;
    for (size_t i = 0; i < pts.size(); i++)
    {
        if (pts[i].y < ymin)
            ymin = pts[i].y;
        if (pts[i].y > ymax)
            ymax = pts[i].y;
    }
    double rng = ymax - ymin;
    if (rng < 1.0)
        rng = 1.0;
    double nLin = rLin / (rng * rng), nPar = rPar / (rng * rng), nSin = rSin / (rng * rng);
    cout << "  归一化: 线性=" << nLin << " 抛物线=" << nPar << " 正弦=" << nSin << endl;
    string type = "unknown";
    if (colorCode == 0)
    {
        if (nPar < nLin * 0.3 && nPar < nSin)
            type = "parabola";
        else if (nLin < 0.02)
            type = "approx_line";
        else
            type = "curve";
    }
    else if (colorCode == 1)
    {
        if (nLin < 0.02)
            type = "line";
        else if (nPar < nLin * 0.5)
            type = "slight_curve";
        else
            type = "approx_line";
    }
    else
    {
        if (nSin < nPar && nSin < nLin && sa > 3.0)
            type = "sinusoidal";
        else if (nPar < nLin)
            type = "curve";
        else
            type = "approx_line";
    }
    return type;
}

string typeNameCN(const string &eng)
{
    if (eng == "parabola")
        return "抛物线运动(抛体轨迹)";
    if (eng == "line")
        return "直线运动(加速下落)";
    if (eng == "sinusoidal")
        return "正弦曲线运动";
    if (eng == "approx_line")
        return "近似直线运动";
    if (eng == "curve")
        return "曲线运动";
    if (eng == "slight_curve")
        return "微弱曲线运动";
    return "未知";
}

string typeNameEN(const string &eng)
{
    if (eng == "parabola")
        return "projectile motion";
    if (eng == "line")
        return "accelerated fall";
    if (eng == "sinusoidal")
        return "sinusoidal path";
    if (eng == "approx_line")
        return "approx linear motion";
    if (eng == "curve")
        return "curved path";
    if (eng == "slight_curve")
        return "slight curve";
    return "unknown";
}

void drawSquareMarker(Mat &img, Point2f center, int size, Scalar color, bool filled)
{
    int hs = size / 2;
    Point tl((int)center.x - hs, (int)center.y - hs);
    Point br((int)center.x + hs, (int)center.y + hs);
    rectangle(img, tl, br, color, filled ? -1 : 1);
}

int main(int argc, char **argv)
{
    namespace fs = std::filesystem;

    cout << "======================================" << endl;
    cout << "    多目标轨迹追踪与分析" << endl;
    cout << "======================================" << endl;

    string imagePath = (argc > 1) ? argv[1] : "input.png";
    fs::path inputPath(imagePath);
    vector<fs::path> searchPaths;

    if (inputPath.is_absolute())
    {
        searchPaths.push_back(inputPath);
    }
    else
    {
        searchPaths.push_back(fs::current_path() / inputPath);
        searchPaths.push_back(fs::path(__FILE__).parent_path() / inputPath);

        if (argc > 0 && argv[0] != nullptr)
        {
            fs::path exePath(argv[0]);
            if (exePath.is_relative())
            {
                exePath = fs::current_path() / exePath;
            }
            if (exePath.has_parent_path())
            {
                searchPaths.push_back(exePath.parent_path() / inputPath);
            }
        }
    }

    fs::path resolvedInput;
    for (const auto &p : searchPaths)
    {
        if (fs::exists(p))
        {
            resolvedInput = p;
            break;
        }
    }

    if (resolvedInput.empty())
    {
        resolvedInput = searchPaths.front();
    }

    Mat src = imread(resolvedInput.string());
    if (src.empty())
    {
        cout << "错误: 无法读取图像 " << resolvedInput.string() << "!" << endl;
        return -1;
    }
    cout << "图像尺寸: " << src.cols << " x " << src.rows << endl;

    Mat hsv;
    cvtColor(src, hsv, COLOR_BGR2HSV);
    ColorCfg red;
    red.lo1 = Scalar(0, 100, 100);
    red.hi1 = Scalar(10, 255, 255);
    red.lo2 = Scalar(170, 100, 100);
    red.hi2 = Scalar(180, 255, 255);
    red.dual = true;
    ColorCfg blue;
    blue.lo1 = Scalar(100, 80, 80);
    blue.hi1 = Scalar(130, 255, 255);
    blue.lo2 = Scalar(0, 0, 0);
    blue.hi2 = Scalar(0, 0, 0);
    blue.dual = false;
    ColorCfg green;
    green.lo1 = Scalar(35, 80, 80);
    green.hi1 = Scalar(85, 255, 255);
    green.lo2 = Scalar(0, 0, 0);
    green.hi2 = Scalar(0, 0, 0);
    green.dual = false;

    auto doMask = [&](const ColorCfg &cfg)
    {
        Mat m1, mask;
        inRange(hsv, cfg.lo1, cfg.hi1, m1);
        if (cfg.dual)
        {
            Mat m2;
            inRange(hsv, cfg.lo2, cfg.hi2, m2);
            bitwise_or(m1, m2, mask);
        }
        else
            mask = m1;
        Mat k = getStructuringElement(MORPH_ELLIPSE, Size(3, 3));
        morphologyEx(mask, mask, MORPH_OPEN, k, Point(-1, -1), 2);
        morphologyEx(mask, mask, MORPH_CLOSE, k, Point(-1, -1), 2);
        return mask;
    };

    vector<Point2f> ptsR = getPoints(doMask(red));
    vector<Point2f> ptsB = getPoints(doMask(blue));
    vector<Point2f> ptsG = getPoints(doMask(green));
    cout << "轨迹点数 - 红色:" << ptsR.size() << " 蓝色:" << ptsB.size() << " 绿色:" << ptsG.size() << endl;

    cout << "\n--- 红色(A) ---" << endl;
    double lenR = 0;
    string typeR = analyze(ptsR, lenR, 0);
    cout << "--- 蓝色(B) ---" << endl;
    double lenB = 0;
    string typeB = analyze(ptsB, lenB, 1);
    cout << "--- 绿色(C) ---" << endl;
    double lenG = 0;
    string typeG = analyze(ptsG, lenG, 2);

    cout << "\n========== 分析结果 ==========" << endl;
    cout << "  物体A(红色): " << typeNameCN(typeR) << "  轨迹长度=" << lenR << " 像素" << endl;
    cout << "  物体B(蓝色): " << typeNameCN(typeB) << "  轨迹长度=" << lenB << " 像素" << endl;
    cout << "  物体C(绿色): " << typeNameCN(typeG) << "  轨迹长度=" << lenG << " 像素" << endl;

    // ==================== 结果图 ====================
    Mat result = src.clone();

    // 网格
    for (int x = 0; x < src.cols; x += 50)
        line(result, Point(x, 0), Point(x, src.rows), Scalar(220, 220, 220), 1);
    for (int y = 0; y < src.rows; y += 50)
        line(result, Point(0, y), Point(src.cols, y), Scalar(220, 220, 220), 1);

    // 连线
    for (size_t i = 0; i + 1 < ptsR.size(); i++)
        line(result, ptsR[i], ptsR[i + 1], Scalar(0, 0, 255), 2, LINE_AA);
    for (size_t i = 0; i + 1 < ptsB.size(); i++)
        line(result, ptsB[i], ptsB[i + 1], Scalar(255, 0, 0), 2, LINE_AA);
    for (size_t i = 0; i + 1 < ptsG.size(); i++)
        line(result, ptsG[i], ptsG[i + 1], Scalar(0, 200, 0), 2, LINE_AA);

    // 方块标记
    for (size_t i = 0; i < ptsR.size(); i++)
        drawSquareMarker(result, ptsR[i], 7, Scalar(0, 0, 255), true);
    for (size_t i = 0; i < ptsB.size(); i++)
        drawSquareMarker(result, ptsB[i], 7, Scalar(255, 0, 0), true);
    for (size_t i = 0; i < ptsG.size(); i++)
        drawSquareMarker(result, ptsG[i], 7, Scalar(0, 200, 0), true);

    // 右上角
    putText(result, "Objects: 3", Point(src.cols - 230, 35),
            FONT_HERSHEY_SIMPLEX, 0.85, Scalar(0, 0, 0), 2, LINE_AA);

    // 中间三行说明文字
    int labelX = 20, labelY = src.rows - 100;
    string txtG = "Traj-C (Green): " + typeNameEN(typeG);
    putText(result, txtG, Point(labelX, labelY), FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0, 180, 0), 2, LINE_AA);
    string txtB = "Traj-B (Blue): " + typeNameEN(typeB);
    putText(result, txtB, Point(labelX, labelY + 22), FONT_HERSHEY_SIMPLEX, 0.5, Scalar(200, 0, 0), 2, LINE_AA);
    string txtR = "Traj-A (Red): " + typeNameEN(typeR);
    putText(result, txtR, Point(labelX, labelY + 44), FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0, 0, 220), 2, LINE_AA);

    cout << "\n完成！" << endl;

    namedWindow("Result", WINDOW_NORMAL);
    imshow("Result", result);
    waitKey(0);
    destroyAllWindows();
    return 0;
}
