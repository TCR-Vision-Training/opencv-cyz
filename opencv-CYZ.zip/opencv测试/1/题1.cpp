#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>
#include <string>
#include <filesystem>

using namespace cv;
using namespace std;

// =====================================================
// 根据轮廓几何特征判断形状
// 不直接根据颜色决定形状
// =====================================================
string detectShape(const vector<Point> &contour)
{
    double area = contourArea(contour);

    // 过滤很小的噪声
    if (area < 500)
    {
        return "Unknown";
    }

    // 计算轮廓周长
    double perimeter = arcLength(contour, true);

    if (perimeter <= 0)
    {
        return "Unknown";
    }

    // 多边形逼近
    vector<Point> approx;

    approxPolyDP(
        contour,
        approx,
        0.02 * perimeter,
        true);

    int vertices = (int)approx.size();

    // 3个顶点：三角形
    if (vertices == 3)
    {
        return "Triangle";
    }

    // 4个顶点：矩形
    if (vertices == 4)
    {
        return "Rectangle";
    }

    // 圆度：
    // 圆形越接近 1
    double circularity =
        4.0 * CV_PI * area /
        (perimeter * perimeter);

    if (circularity > 0.78)
    {
        return "Circle";
    }

    return "Unknown";
}

// =====================================================
// 处理一个颜色区域
// HSV颜色只用于分开重叠物体
// 最终形状由 detectShape() 判断
// =====================================================
void processColor(
    const Mat &hsv,
    Mat &result,
    Scalar lowerColor,
    Scalar upperColor,
    int &circleNum,
    int &rectNum,
    int &triangleNum)
{
    Mat mask;

    // 提取指定HSV颜色范围
    inRange(
        hsv,
        lowerColor,
        upperColor,
        mask);

    // 形态学去噪
    Mat kernel =
        getStructuringElement(
            MORPH_ELLIPSE,
            Size(3, 3));

    morphologyEx(
        mask,
        mask,
        MORPH_OPEN,
        kernel);

    morphologyEx(
        mask,
        mask,
        MORPH_CLOSE,
        kernel);

    // 查找该颜色区域的轮廓
    vector<vector<Point>> contours;

    findContours(
        mask,
        contours,
        RETR_EXTERNAL,
        CHAIN_APPROX_SIMPLE);

    // 逐个处理轮廓
    for (size_t i = 0;
         i < contours.size();
         i++)
    {
        double area =
            contourArea(contours[i]);

        // 过滤噪声
        if (area < 500)
        {
            continue;
        }

        // 根据几何特征判断形状
        string shape =
            detectShape(contours[i]);

        if (shape == "Unknown")
        {
            continue;
        }

        // 获取外接矩形
        Rect box =
            boundingRect(contours[i]);

        // 计算中心位置
        Point center(
            box.x + box.width / 2,
            box.y + box.height / 2);

        Scalar drawColor;

        string label;

        // 圆形
        if (shape == "Circle")
        {
            circleNum++;

            label =
                "C" +
                to_string(circleNum);

            // 绿色轮廓
            drawColor =
                Scalar(0, 255, 0);
        }

        // 矩形
        else if (shape == "Rectangle")
        {
            rectNum++;

            label =
                "R" +
                to_string(rectNum);

            // 蓝色轮廓
            drawColor =
                Scalar(255, 0, 0);
        }

        // 三角形
        else if (shape == "Triangle")
        {
            triangleNum++;

            label =
                "T" +
                to_string(triangleNum);

            // 红色轮廓
            drawColor =
                Scalar(0, 0, 255);
        }

        // 绘制轮廓
        drawContours(
            result,
            contours,
            (int)i,
            drawColor,
            3);

        // 绘制编号
        putText(
            result,
            label,
            center,
            FONT_HERSHEY_SIMPLEX,
            0.7,
            drawColor,
            2);
    }
}

// =====================================================
// 主函数
// =====================================================
int main(int argc, char **argv)
{
    // 图片路径（命令行参数，默认 input.png）
    string imagePath = (argc > 1) ? argv[1] : "input.png";

    namespace fs = std::filesystem;

    fs::path inputPath(imagePath);
    vector<fs::path> searchPaths;

    if (inputPath.is_absolute())
    {
        searchPaths.push_back(inputPath);
    }
    else
    {
        searchPaths.push_back(fs::current_path() / inputPath);
        searchPaths.push_back(fs::path(__FILE__).parent_path() / inputPath);

        if (argc > 0 && argv[0] != nullptr)
        {
            fs::path exePath(argv[0]);
            if (exePath.is_relative())
            {
                exePath = fs::current_path() / exePath;
            }

            if (exePath.has_parent_path())
            {
                searchPaths.push_back(exePath.parent_path() / inputPath);
            }
        }
    }

    fs::path resolvedInput;
    for (const auto &p : searchPaths)
    {
        if (fs::exists(p))
        {
            resolvedInput = p;
            break;
        }
    }

    if (resolvedInput.empty())
    {
        resolvedInput = searchPaths.front();
    }

    string imagePathResolved = resolvedInput.string();

    // 读取图片
    Mat src =
        imread(imagePathResolved);

    if (src.empty())
    {
        cout
            << "图片读取失败！"
            << endl;

        cout
            << "图片路径："
            << imagePathResolved
            << endl;

        return -1;
    }

    // 保存结果图
    Mat result =
        src.clone();

    // 转换到HSV颜色空间
    Mat hsv;

    cvtColor(
        src,
        hsv,
        COLOR_BGR2HSV);

    // 统计变量
    int circleNum = 0;

    int rectNum = 0;

    int triangleNum = 0;

    // =================================================
    // 处理红色
    //
    // 红色Hue跨越0，
    // 所以需要分成两个范围
    // =================================================

    processColor(
        hsv,
        result,

        Scalar(0, 80, 80),
        Scalar(10, 255, 255),

        circleNum,
        rectNum,
        triangleNum);

    processColor(
        hsv,
        result,

        Scalar(170, 80, 80),
        Scalar(180, 255, 255),

        circleNum,
        rectNum,
        triangleNum);

    // =================================================
    // 处理蓝色
    // =================================================

    processColor(
        hsv,
        result,

        Scalar(100, 80, 80),
        Scalar(135, 255, 255),

        circleNum,
        rectNum,
        triangleNum);

    // =================================================
    // 处理绿色
    // =================================================

    processColor(
        hsv,
        result,

        Scalar(40, 70, 70),
        Scalar(90, 255, 255),

        circleNum,
        rectNum,
        triangleNum);

    // =================================================
    // 处理黄色
    // =================================================

    processColor(
        hsv,
        result,

        Scalar(20, 80, 80),
        Scalar(40, 255, 255),

        circleNum,
        rectNum,
        triangleNum);

    // =================================================
    // 处理橙色
    // =================================================

    processColor(
        hsv,
        result,

        Scalar(5, 80, 80),
        Scalar(20, 255, 255),

        circleNum,
        rectNum,
        triangleNum);

    // =================================================
    // 处理紫色
    // =================================================

    processColor(
        hsv,
        result,

        Scalar(135, 50, 50),
        Scalar(170, 255, 255),

        circleNum,
        rectNum,
        triangleNum);

    // 输出统计结果
    cout << endl;

    cout
        << "Circles: "
        << circleNum
        << endl;

    cout
        << "Rects: "
        << rectNum
        << endl;

    cout
        << "Triangles: "
        << triangleNum
        << endl;

    // 在结果图上显示统计信息
    string totalText =
        "Circles: " +
        to_string(circleNum) +
        "  Rects: " +
        to_string(rectNum) +
        "  Triangles: " +
        to_string(triangleNum);

    putText(
        result,
        totalText,
        Point(20, 40),
        FONT_HERSHEY_SIMPLEX,
        0.8,
        Scalar(0, 0, 0),
        2);

    fs::path outputPath = resolvedInput.parent_path() / "result.png";
    imwrite(outputPath.string(), result);
    cout << "结果已保存到: " << outputPath.string() << endl;

    namedWindow("Result", WINDOW_NORMAL);
    imshow("Result", result);
    waitKey(0);
    destroyAllWindows();

    return 0;
}
