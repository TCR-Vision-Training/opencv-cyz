#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <filesystem>

using namespace cv;
using namespace std;

// ============================================
// Zhang-Suen 骨架细化
// ============================================
void zhangSuenThinning(Mat &img)
{
    if (img.empty())
        return;
    Mat prev = Mat::zeros(img.size(), CV_8UC1);
    Mat diff;
    do
    {
        vector<Point> m1;
        for (int y = 1; y < img.rows - 1; y++)
            for (int x = 1; x < img.cols - 1; x++)
            {
                if (img.at<uchar>(y, x) == 0)
                    continue;
                uchar p2 = img.at<uchar>(y - 1, x), p3 = img.at<uchar>(y - 1, x + 1);
                uchar p4 = img.at<uchar>(y, x + 1), p5 = img.at<uchar>(y + 1, x + 1);
                uchar p6 = img.at<uchar>(y + 1, x), p7 = img.at<uchar>(y + 1, x - 1);
                uchar p8 = img.at<uchar>(y, x - 1), p9 = img.at<uchar>(y - 1, x - 1);
                int A = (p2 == 0 && p3 == 1) + (p3 == 0 && p4 == 1) + (p4 == 0 && p5 == 1) + (p5 == 0 && p6 == 1) + (p6 == 0 && p7 == 1) + (p7 == 0 && p8 == 1) + (p8 == 0 && p9 == 1) + (p9 == 0 && p2 == 1);
                int B = p2 + p3 + p4 + p5 + p6 + p7 + p8 + p9;
                if (A == 1 && B >= 2 && B <= 6 && p2 * p4 * p6 == 0 && p4 * p6 * p8 == 0)
                    m1.push_back(Point(x, y));
            }
        for (size_t i = 0; i < m1.size(); i++)
            img.at<uchar>(m1[i].y, m1[i].x) = 0;

        vector<Point> m2;
        for (int y = 1; y < img.rows - 1; y++)
            for (int x = 1; x < img.cols - 1; x++)
            {
                if (img.at<uchar>(y, x) == 0)
                    continue;
                uchar p2 = img.at<uchar>(y - 1, x), p3 = img.at<uchar>(y - 1, x + 1);
                uchar p4 = img.at<uchar>(y, x + 1), p5 = img.at<uchar>(y + 1, x + 1);
                uchar p6 = img.at<uchar>(y + 1, x), p7 = img.at<uchar>(y + 1, x - 1);
                uchar p8 = img.at<uchar>(y, x - 1), p9 = img.at<uchar>(y - 1, x - 1);
                int A = (p2 == 0 && p3 == 1) + (p3 == 0 && p4 == 1) + (p4 == 0 && p5 == 1) + (p5 == 0 && p6 == 1) + (p6 == 0 && p7 == 1) + (p7 == 0 && p8 == 1) + (p8 == 0 && p9 == 1) + (p9 == 0 && p2 == 1);
                int B = p2 + p3 + p4 + p5 + p6 + p7 + p8 + p9;
                if (A == 1 && B >= 2 && B <= 6 && p2 * p4 * p8 == 0 && p2 * p6 * p8 == 0)
                    m2.push_back(Point(x, y));
            }
        for (size_t i = 0; i < m2.size(); i++)
            img.at<uchar>(m2[i].y, m2[i].x) = 0;

        absdiff(img, prev, diff);
        prev = img.clone();
    } while (countNonZero(diff) > 0);
}

// ============================================
// 骨架路径长度 (修复版)
// ============================================
double calcPathLength(const vector<Point> &pts)
{
    if (pts.empty())
        return 0.0;
    if (pts.size() < 2)
        return (double)pts.size();

    int n = (int)pts.size();

    // 构建邻接表
    vector<vector<int>> adj(n);
    for (int i = 0; i < n; i++)
        for (int j = i + 1; j < n; j++)
            if (abs(pts[i].x - pts[j].x) <= 1 && abs(pts[i].y - pts[j].y) <= 1)
            {
                adj[i].push_back(j);
                adj[j].push_back(i);
            }

    // 找端点(度=1)
    vector<int> endpoints;
    for (int i = 0; i < n; i++)
        if ((int)adj[i].size() == 1)
            endpoints.push_back(i);

    // ---- 修复: 处理各种端点数量情况 ----
    if (endpoints.size() >= 2)
    {
        // 正常情况: 至少2个端点, 找最远端点对
        double maxLen = 0;
        for (size_t s = 0; s < endpoints.size(); s++)
        {
            vector<bool> vis(n, false);
            vector<double> dist(n, 0);
            vector<int> stk;
            stk.push_back(endpoints[s]);
            while (!stk.empty())
            {
                int u = stk.back();
                stk.pop_back();
                if (vis[u])
                    continue;
                vis[u] = true;
                for (size_t j = 0; j < adj[u].size(); j++)
                {
                    int v = adj[u][j];
                    if (!vis[v])
                    {
                        double dx = pts[v].x - pts[u].x, dy = pts[v].y - pts[u].y;
                        dist[v] = dist[u] + sqrt(dx * dx + dy * dy);
                        stk.push_back(v);
                    }
                }
            }
            for (size_t t = s + 1; t < endpoints.size(); t++)
                if (dist[endpoints[t]] > maxLen)
                    maxLen = dist[endpoints[t]];
        }
        return maxLen;
    }
    else if (endpoints.size() == 1)
    {
        // 只有1个端点(环+尾巴), BFS求最大距离
        vector<bool> vis(n, false);
        vector<double> dist(n, 0);
        vector<int> stk;
        stk.push_back(endpoints[0]);
        double maxDist = 0;
        while (!stk.empty())
        {
            int u = stk.back();
            stk.pop_back();
            if (vis[u])
                continue;
            vis[u] = true;
            for (size_t j = 0; j < adj[u].size(); j++)
            {
                int v = adj[u][j];
                if (!vis[v])
                {
                    double dx = pts[v].x - pts[u].x, dy = pts[v].y - pts[u].y;
                    dist[v] = dist[u] + sqrt(dx * dx + dy * dy);
                    maxDist = max(maxDist, dist[v]);
                    stk.push_back(v);
                }
            }
        }
        return maxDist;
    }
    else
    {
        // 0个端点: 纯环形, 用总像素数作为近似
        return (double)n;
    }
}

struct CrackInfo
{
    int id, pixelCount;
    double pathLength;
    Point2f center;
    vector<Point> pts;
};

// ============================================
int main(int argc, char **argv)
{
    namespace fs = std::filesystem;

    try
    {
        string imgPath = (argc > 1) ? argv[1] : "input.png";

        fs::path inputPath(imgPath);
        vector<fs::path> searchPaths;

        if (inputPath.is_absolute())
        {
            searchPaths.push_back(inputPath);
        }
        else
        {
            searchPaths.push_back(fs::current_path() / inputPath);
            searchPaths.push_back(fs::path(__FILE__).parent_path() / inputPath);

            if (argc > 0 && argv[0] != nullptr)
            {
                fs::path exePath(argv[0]);
                if (exePath.is_relative())
                {
                    exePath = fs::current_path() / exePath;
                }

                if (exePath.has_parent_path())
                {
                    searchPaths.push_back(exePath.parent_path() / inputPath);
                }
            }
        }

        fs::path resolvedInput;
        for (const auto &p : searchPaths)
        {
            if (fs::exists(p))
            {
                resolvedInput = p;
                break;
            }
        }

        if (resolvedInput.empty())
        {
            resolvedInput = searchPaths.front();
        }

        Mat src = imread(resolvedInput.string(), IMREAD_COLOR);
        if (src.empty())
        {
            cerr << "错误: 无法加载图像 " << resolvedInput.string() << endl;
            return -1;
        }

        Mat gray;
        cvtColor(src, gray, COLOR_BGR2GRAY);
        GaussianBlur(gray, gray, Size(3, 3), 0);

        // --- Black Top-Hat 多尺度增强 ---
        Mat tophatCombined;
        {
            Mat k1 = getStructuringElement(MORPH_ELLIPSE, Size(7, 7));
            Mat k2 = getStructuringElement(MORPH_ELLIPSE, Size(15, 15));
            Mat k3 = getStructuringElement(MORPH_ELLIPSE, Size(25, 25));
            Mat th1, th2, th3;
            morphologyEx(gray, th1, MORPH_BLACKHAT, k1);
            morphologyEx(gray, th2, MORPH_BLACKHAT, k2);
            morphologyEx(gray, th3, MORPH_BLACKHAT, k3);
            max(th1, th2, tophatCombined);
            max(tophatCombined, th3, tophatCombined);
        }

        // --- 二值化 + 闭运算连接 ---
        Mat binaryFull;
        double otsuT = threshold(tophatCombined, binaryFull, 0, 255, THRESH_BINARY | THRESH_OTSU);
        Mat closeK = getStructuringElement(MORPH_ELLIPSE, Size(19, 19));
        morphologyEx(binaryFull, binaryFull, MORPH_CLOSE, closeK);

        // --- 连通域: 按TopHat响应过滤 ---
        Mat labels, stats, centroids;
        int nLabels = connectedComponentsWithStats(binaryFull, labels, stats, centroids, 8);

        Mat cleaned = Mat::zeros(gray.size(), CV_8UC1);
        for (int i = 1; i < nLabels; i++)
        {
            int area = stats.at<int>(i, CC_STAT_AREA);
            int w = stats.at<int>(i, CC_STAT_WIDTH);
            int h = stats.at<int>(i, CC_STAT_HEIGHT);
            double aspect = (double)max(w, h) / (double)max(min(w, h), 1);

            double sum = 0;
            int cnt = 0;
            for (int y = 0; y < gray.rows; y++)
                for (int x = 0; x < gray.cols; x++)
                    if (labels.at<int>(y, x) == i)
                    {
                        sum += tophatCombined.at<uchar>(y, x);
                        cnt++;
                    }
            double avg = cnt > 0 ? sum / cnt : 0;

            if (area < 30 || avg < otsuT * 0.8 || (aspect < 1.5 && area < 140))
                continue;

            for (int y = 0; y < gray.rows; y++)
                for (int x = 0; x < gray.cols; x++)
                    if (labels.at<int>(y, x) == i)
                        cleaned.at<uchar>(y, x) = 255;
        }

        // --- 骨架提取 ---
        Mat skeleton;
        cleaned.copyTo(skeleton);
        zhangSuenThinning(skeleton);

        // --- 骨架连通域 + 长度 ---
        Mat sLabels, sStats, sCentroids;
        int sN = connectedComponentsWithStats(skeleton, sLabels, sStats, sCentroids, 8);

        vector<CrackInfo> cracks;
        for (int i = 1; i < sN; i++)
        {
            int area = sStats.at<int>(i, CC_STAT_AREA);
            int w = sStats.at<int>(i, CC_STAT_WIDTH);
            int h = sStats.at<int>(i, CC_STAT_HEIGHT);
            double aspect = (double)max(w, h) / (double)max(min(w, h), 1);
            if (area < 20 || aspect > 30.0)
                continue;

            CrackInfo ci;
            ci.pixelCount = area;
            ci.center = Point2f((float)sCentroids.at<double>(i, 0), (float)sCentroids.at<double>(i, 1));

            // 先收集点
            for (int y = 0; y < skeleton.rows; y++)
                for (int x = 0; x < skeleton.cols; x++)
                    if (sLabels.at<int>(y, x) == i)
                        ci.pts.push_back(Point(x, y));

            // 再计算长度，并去掉极短的噪声裂纹
            ci.pathLength = calcPathLength(ci.pts);
            if (ci.pathLength < 120.0 || ci.pixelCount < 80)
                continue;
            cracks.push_back(ci);
        }

        // 排序: 按长度降序
        sort(cracks.begin(), cracks.end(),
             [](const CrackInfo &a, const CrackInfo &b)
             { return a.pathLength > b.pathLength; });
        for (size_t i = 0; i < cracks.size(); i++)
            cracks[i].id = (int)i + 1;

        // ========== 控制台输出 ==========
        cout << "========================================" << endl;
        cout << "  焊缝裂纹检测结果" << endl;
        cout << "========================================" << endl;
        cout << "裂纹数量: " << cracks.size() << " 条" << endl;
        cout << "----------------------------------------" << endl;
        double maxLen = 0;
        for (size_t i = 0; i < cracks.size(); i++)
        {
            cout << "Crack-" << cracks[i].id
                 << "  像素: " << cracks[i].pixelCount
                 << "  长度: " << fixed << setprecision(1) << cracks[i].pathLength << " 像素" << endl;
            maxLen = max(maxLen, cracks[i].pathLength);
        }
        cout << "----------------------------------------" << endl;
        cout << "最长裂纹: " << fixed << setprecision(1) << maxLen << " 像素" << endl;
        cout << "========================================" << endl;

        // ========== 最终图像 ==========
        Mat result = src.clone();
        Scalar colors[] = {
            Scalar(0, 0, 255), Scalar(0, 255, 0), Scalar(255, 0, 0),
            Scalar(0, 255, 255), Scalar(255, 0, 255), Scalar(255, 255, 0)};
        for (size_t i = 0; i < cracks.size(); i++)
        {
            Scalar c = colors[i % 6];
            for (size_t j = 0; j < cracks[i].pts.size(); j++)
                circle(result, cracks[i].pts[j], 2, c, -1);
            putText(result, "Crack-" + to_string(cracks[i].id),
                    Point((int)cracks[i].center.x + 15, (int)cracks[i].center.y - 8),
                    FONT_HERSHEY_SIMPLEX, 0.55, c, 2, LINE_AA);
        }
        putText(result, "Cracks Detected: " + to_string(cracks.size()),
                Point(10, 35), FONT_HERSHEY_SIMPLEX, 0.85, Scalar(0, 255, 0), 2, LINE_AA);

        namedWindow("Result", WINDOW_NORMAL);
        imshow("Result", result);
        waitKey(0);
        destroyAllWindows();
    }
    catch (cv::Exception &e)
    {
        cerr << "OpenCV异常: " << e.what() << endl;
        return -1;
    }
    return 0;
}
