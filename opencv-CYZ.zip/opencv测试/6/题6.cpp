#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <map>
#include <filesystem>

using namespace cv;
using namespace std;

int main(int argc, char **argv)
{
    namespace fs = std::filesystem;

    string inputPath = (argc > 1) ? argv[1] : "input.png";

    fs::path path(inputPath);
    vector<fs::path> searchPaths;

    if (path.is_absolute())
    {
        searchPaths.push_back(path);
    }
    else
    {
        searchPaths.push_back(fs::current_path() / path);
        searchPaths.push_back(fs::path(__FILE__).parent_path() / path);

        if (argc > 0 && argv[0] != nullptr)
        {
            fs::path exePath(argv[0]);
            if (exePath.is_relative())
            {
                exePath = fs::current_path() / exePath;
            }

            if (exePath.has_parent_path())
            {
                searchPaths.push_back(exePath.parent_path() / path);
            }
        }
    }

    fs::path resolvedInput;
    for (const auto &p : searchPaths)
    {
        if (fs::exists(p))
        {
            resolvedInput = p;
            break;
        }
    }

    if (resolvedInput.empty())
    {
        resolvedInput = searchPaths.front();
    }

    // 读取输入图像
    Mat src = imread(resolvedInput.string());
    if (src.empty())
    {
        cerr << "错误：无法读取图像 '" << resolvedInput.string() << "'" << endl;
        return -1;
    }

    cout << "========================================" << endl;
    cout << "    颗粒计数与面积分析程序" << endl;
    cout << "========================================" << endl;

    // ==================== 1. 预处理 ====================
    Mat gray;
    cvtColor(src, gray, COLOR_BGR2GRAY);

    Mat blurred;
    GaussianBlur(gray, blurred, Size(5, 5), 0);

    Mat binary;
    double thresh = threshold(blurred, binary, 0, 255, THRESH_BINARY_INV + THRESH_OTSU);
    cout << "[预处理] Otsu阈值: " << thresh << endl;

    // ==================== 2. 形态学操作 ====================
    // 先开运算去噪，再闭运算填洞
    Mat kernel = getStructuringElement(MORPH_ELLIPSE, Size(3, 3));
    Mat opening;
    morphologyEx(binary, opening, MORPH_OPEN, kernel, Point(-1, -1), 2);
    Mat closing;
    morphologyEx(opening, closing, MORPH_CLOSE, kernel, Point(-1, -1), 2);

    cout << "[形态学] 开运算 + 闭运算 完成" << endl;

    // ==================== 3. 距离变换 ====================
    Mat distTransform;
    distanceTransform(closing, distTransform, DIST_L2, 3);

    Mat distNorm;
    normalize(distTransform, distNorm, 0, 1, NORM_MINMAX);

    double maxDist;
    minMaxLoc(distTransform, nullptr, &maxDist);
    cout << "[距离变换] 最大距离: " << maxDist << endl;

    // ==================== 4. ★★★ 结合两者的优势 ★★★ ====================
    //   来自"你的代码"：sureBg + unknown = 0 的正确分水岭框架
    //   来自"我的代码"：降低前景阈值 → 检测更多种子

    // ★ 前景阈值：用自适应方式但更宽松
    //   你的代码用 maxDist * 0.4（保守，漏检小颗粒）
    //   我们用 maxDist * 0.2（宽松，检测更多）
    double fgThreshold = maxDist * 0.2;
    Mat sureFg;
    threshold(distTransform, sureFg, fgThreshold, 255, THRESH_BINARY);
    sureFg.convertTo(sureFg, CV_8U);
    cout << "[前景] 前景阈值: " << fgThreshold << endl;

    // ★ 来自你的代码：正确的背景 + 未知区域构建
    Mat sureBg;
    dilate(closing, sureBg, kernel, Point(-1, -1), 3);

    Mat unknown;
    subtract(sureBg, sureFg, unknown);

    // ★ 来自你的代码：正确的标记构建
    Mat markers;
    connectedComponents(sureFg, markers);
    markers = markers + 1; // 背景从0变1，前景从1变2

    // ★★ 来自你的代码：未知区域标记为0（关键！）★★
    for (int i = 0; i < unknown.rows; i++)
    {
        for (int j = 0; j < unknown.cols; j++)
        {
            if (unknown.at<uchar>(i, j) == 255)
            {
                markers.at<int>(i, j) = 0;
            }
        }
    }

    {
        Mat tempLabels;
        int tempN = connectedComponents(sureFg, tempLabels, 8);
        cout << "[分水岭] 前景种子数: " << tempN - 1 << endl;
    }
    // ==================== 5. 分水岭分割 ====================
    watershed(src, markers);
    cout << "[分水岭] 分割完成" << endl;

    // ==================== 6. ★★★ 轮廓提取（你的方法：更精确） ★★★
    // 来自你的代码：将所有 >1 的区域合并成一张图，统一找轮廓
    Mat watershedResult = Mat::zeros(closing.size(), CV_8UC1);
    for (int i = 0; i < markers.rows; i++)
    {
        for (int j = 0; j < markers.cols; j++)
        {
            int val = markers.at<int>(i, j);
            if (val > 1)
            {
                watershedResult.at<uchar>(i, j) = 255;
            }
        }
    }

    // ★ 额外步骤：用原始二值掩膜裁切，使轮廓精确贴合
    Mat refinedResult;
    bitwise_and(watershedResult, closing, refinedResult);

    vector<vector<Point>> contours;
    findContours(refinedResult.clone(), contours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

    // ==================== 7. 过滤 ====================
    double imgArea = src.cols * src.rows;
    double minArea = imgArea * 0.0005;
    double maxArea = imgArea * 0.5;

    vector<vector<Point>> validContours;
    vector<double> contourAreas;

    for (size_t i = 0; i < contours.size(); i++)
    {
        double area = contourArea(contours[i]);
        if (area >= minArea && area <= maxArea)
        {
            validContours.push_back(contours[i]);
            contourAreas.push_back(area);
        }
    }

    cout << "[轮廓提取] 有效颗粒数: " << validContours.size() << endl;

    // ==================== 8. 面积统计 ====================
    double totalArea = 0;
    double maxAreaVal = 0, minAreaVal = DBL_MAX;
    for (size_t i = 0; i < contourAreas.size(); i++)
    {
        totalArea += contourAreas[i];
        maxAreaVal = max(maxAreaVal, contourAreas[i]);
        minAreaVal = min(minAreaVal, contourAreas[i]);
    }
    double avgArea = contourAreas.size() > 0 ? totalArea / contourAreas.size() : 0;

    int largeCount = 0, mediumCount = 0, smallCount = 0;
    double largeThreshold = avgArea * 1.3;
    double smallThreshold = avgArea * 0.7;

    for (size_t i = 0; i < contourAreas.size(); i++)
    {
        if (contourAreas[i] >= largeThreshold)
            largeCount++;
        else if (contourAreas[i] <= smallThreshold)
            smallCount++;
        else
            mediumCount++;
    }

    cout << "========== 颗粒统计结果 ==========" << endl;
    cout << "有效颗粒总数: " << validContours.size() << endl;
    cout << "总面积: " << (int)totalArea << " 像素" << endl;
    cout << "平均面积: " << (int)avgArea << " 像素" << endl;
    cout << "最大: " << (int)maxAreaVal << "  最小: " << (int)minAreaVal << endl;
    cout << "  大颗粒: " << largeCount << "  中颗粒: " << mediumCount
         << "  小颗粒: " << smallCount << endl;

    for (size_t i = 0; i < contourAreas.size(); i++)
    {
        cout << "  颗粒 #" << (i + 1) << ": " << (int)contourAreas[i] << " px²" << endl;
    }

    // ==================== 9. 绘制结果 ====================
    Mat result = src.clone();

    // 紫色轮廓线
    Scalar contourColor(128, 0, 128);
    drawContours(result, validContours, -1, contourColor, 2, LINE_8);

    // 蓝色编号
    Scalar textColor(255, 0, 0);
    for (size_t i = 0; i < validContours.size(); i++)
    {
        Moments m = moments(validContours[i]);
        int cx = (int)(m.m10 / m.m00);
        int cy = (int)(m.m01 / m.m00);

        string label = to_string(i + 1);
        int fontFace = FONT_HERSHEY_SIMPLEX;
        double fontScale = 0.4;
        int thickness = 1;
        int baseline = 0;
        Size textSize = getTextSize(label, fontFace, fontScale, thickness, &baseline);

        rectangle(result,
                  Point(cx - textSize.width / 2 - 2, cy - textSize.height / 2 - 2),
                  Point(cx + textSize.width / 2 + 2, cy + textSize.height / 2 + 2),
                  Scalar(255, 255, 255), -1);

        putText(result, label,
                Point(cx - textSize.width / 2, cy + textSize.height / 2),
                fontFace, fontScale, textColor, thickness, LINE_AA);
    }

    // 左上角统计
    string infoText = "Valid Particles: " + to_string(validContours.size());
    rectangle(result, Rect(5, 5, 220, 30), Scalar(255, 255, 255), -1);
    putText(result, infoText, Point(10, 25),
            FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 255), 2, LINE_AA);

    cout << "========================================" << endl;

    namedWindow("Result", WINDOW_NORMAL);
    imshow("Result", result);
    waitKey(0);
    destroyAllWindows();

    return 0;
}
