#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <filesystem>

using namespace cv;
using namespace std;

// ==================== 数据结构 ====================
struct Ray
{
    Point2f endpoint; // 射线远端点
    double angle;     // 绝对方向角（数学坐标系，0°=右，逆时针为正）
    double length;    // 射线长度
};

// ==================== 辅助函数 ====================

// 归一化角度到 [0, 360)
double normDeg(double a)
{
    while (a < 0)
        a += 360;
    while (a >= 360)
        a -= 360;
    return a;
}

// 两条射线之间的较短夹角 [0, 180]
double shortAngle(double a, double b)
{
    double d = fabs(normDeg(a) - normDeg(b));
    return d > 180.0 ? 360.0 - d : d;
}

// ==================== 主函数 ====================
int main(int argc, char **argv)
{
    namespace fs = std::filesystem;

    // ---------- 1. 读取图像 ----------
    string filename = (argc > 1) ? argv[1] : "input.png";

    fs::path inputPath(filename);
    vector<fs::path> searchPaths;

    if (inputPath.is_absolute())
    {
        searchPaths.push_back(inputPath);
    }
    else
    {
        searchPaths.push_back(fs::current_path() / inputPath);
        searchPaths.push_back(fs::path(__FILE__).parent_path() / inputPath);

        if (argc > 0 && argv[0] != nullptr)
        {
            fs::path exePath(argv[0]);
            if (exePath.is_relative())
            {
                exePath = fs::current_path() / exePath;
            }

            if (exePath.has_parent_path())
            {
                searchPaths.push_back(exePath.parent_path() / inputPath);
            }
        }
    }

    fs::path resolvedInput;
    for (const auto &p : searchPaths)
    {
        if (fs::exists(p))
        {
            resolvedInput = p;
            break;
        }
    }

    if (resolvedInput.empty())
    {
        resolvedInput = searchPaths.front();
    }

    Mat img = imread(resolvedInput.string());
    if (img.empty())
    {
        cerr << "无法加载图像: " << resolvedInput.string() << endl;
        return -1;
    }

    Mat result = img.clone();
    int W = img.cols, H = img.rows;

    // ---------- 2. 检测中心点 P（HSV 红色检测）----------
    Mat hsv, redMask;
    cvtColor(img, hsv, COLOR_BGR2HSV);

    Mat mask1, mask2;
    inRange(hsv, Scalar(0, 80, 80), Scalar(10, 255, 255), mask1);
    inRange(hsv, Scalar(160, 80, 80), Scalar(180, 255, 255), mask2);
    redMask = mask1 | mask2;

    // 形态学操作去除噪点
    Mat kernel = getStructuringElement(MORPH_ELLIPSE, Size(5, 5));
    morphologyEx(redMask, redMask, MORPH_CLOSE, kernel);
    morphologyEx(redMask, redMask, MORPH_OPEN, kernel);

    // 通过矩计算质心
    Point2f center(W / 2.0f, H / 2.0f);
    Moments m = moments(redMask, true);
    if (m.m00 > 0)
    {
        center = Point2f(float(m.m10 / m.m00), float(m.m01 / m.m00));
    }
    cout << "[中心点] P = (" << (int)center.x << ", " << (int)center.y << ")" << endl;

    // ---------- 3. HoughLinesP 检测直线段 ----------
    Mat gray, binary;
    cvtColor(img, gray, COLOR_BGR2GRAY);
    // 黑线白底 → 反转为白线黑底
    threshold(gray, binary, 127, 255, THRESH_BINARY_INV);

    vector<Vec4i> segments;
    HoughLinesP(binary, segments, 1, CV_PI / 180,
                50,  // 累加器阈值
                30,  // 最短线段长度
                10); // 线段内最大间隙

    cout << "[检测] HoughLinesP 检测到 " << segments.size() << " 条线段" << endl;

    // ---------- 4. 从中心 P 提取射线 ----------
    double cThresh = max(W, H) * 0.08; // 中心判定阈值
    vector<Ray> rays;

    for (size_t k = 0; k < segments.size(); k++)
    {
        const Vec4i &seg = segments[k];
        Point2f p1(seg[0], seg[1]), p2(seg[2], seg[3]);
        double d1 = norm(p1 - center);
        double d2 = norm(p2 - center);

        // 情况A：一端在中心附近 → 产生一条射线
        if (d1 < cThresh && d2 >= cThresh)
        {
            double dx = p2.x - center.x;
            double dy = -(p2.y - center.y); // 图像Y轴翻转为数学坐标
            double len = hypot(dx, dy);
            if (len > 15)
                rays.push_back({p2, normDeg(atan2(dy, dx) * 180.0 / CV_PI), len});
        }
        else if (d2 < cThresh && d1 >= cThresh)
        {
            double dx = p1.x - center.x;
            double dy = -(p1.y - center.y);
            double len = hypot(dx, dy);
            if (len > 15)
                rays.push_back({p1, normDeg(atan2(dy, dx) * 180.0 / CV_PI), len});
        }
        // 情况B：两端都远离中心 → 判断线段是否穿过中心
        else if (d1 >= cThresh && d2 >= cThresh)
        {
            Point2f dir = p2 - p1;
            double L = norm(dir);
            if (L < 1)
                continue;
            dir /= L;
            double proj = (center - p1).dot(dir);

            if (proj > 0 && proj < L)
            {
                Point2f closest = p1 + proj * dir;
                if (norm(center - closest) < cThresh * 0.5)
                {
                    // 产生两条射线
                    double dx1 = p1.x - center.x, dy1 = -(p1.y - center.y);
                    double len1 = hypot(dx1, dy1);
                    if (len1 > 15)
                        rays.push_back({p1, normDeg(atan2(dy1, dx1) * 180.0 / CV_PI), len1});

                    double dx2 = p2.x - center.x, dy2 = -(p2.y - center.y);
                    double len2 = hypot(dx2, dy2);
                    if (len2 > 15)
                        rays.push_back({p2, normDeg(atan2(dy2, dx2) * 180.0 / CV_PI), len2});
                }
            }
        }
    }

    // ---------- 5. 合并方向相近的射线（12°以内合并）----------
    sort(rays.begin(), rays.end(),
         [](const Ray &a, const Ray &b)
         { return a.angle < b.angle; });

    vector<Ray> merged;
    for (size_t i = 0; i < rays.size(); i++)
    {
        bool found = false;
        for (size_t j = 0; j < merged.size(); j++)
        {
            if (shortAngle(rays[i].angle, merged[j].angle) < 12.0)
            {
                if (rays[i].length > merged[j].length)
                    merged[j] = rays[i]; // 保留更长的
                found = true;
                break;
            }
        }
        if (!found)
            merged.push_back(rays[i]);
    }
    // 处理 0°/360° 环绕合并
    if (merged.size() > 1 &&
        shortAngle(merged.front().angle, merged.back().angle) < 12.0)
    {
        if (merged.front().length > merged.back().length)
            merged.pop_back();
        else
            merged.erase(merged.begin());
    }

    cout << "[合并] 有效射线数: " << merged.size() << endl;

    // ---------- 6. 确定参考射线 PA（最接近 0° 即水平向右）----------
    int refIdx = 0;
    for (int i = 1; i < (int)merged.size(); i++)
    {
        double a1 = min(merged[i].angle, 360.0 - merged[i].angle); // 到0°的距离
        double a0 = min(merged[refIdx].angle, 360.0 - merged[refIdx].angle);
        if (a1 < a0)
            refIdx = i;
    }

    double refAngle = merged[refIdx].angle;
    cout << "[基准] PA 绝对角度 = " << (int)round(refAngle) << "°" << endl;

    // ---------- 7. 给射线分配标签（按逆时针方向从 PA 排序）----------
    vector<pair<double, int>> others; // (CCW角度, 索引)
    for (int i = 0; i < (int)merged.size(); i++)
    {
        if (i == refIdx)
            continue;
        double ccw = normDeg(merged[i].angle - refAngle); // 从 PA 逆时针到此射线的角度
        others.push_back(make_pair(ccw, i));
    }
    sort(others.begin(), others.end());

    // 标签分配
    vector<pair<char, int>> labels;
    labels.push_back(make_pair('A', refIdx));
    char ch = 'B';
    for (size_t i = 0; i < others.size(); i++)
        labels.push_back(make_pair(ch++, others[i].second));

    // ---------- 8. 输出角度结果 ----------
    cout << "\n========================================" << endl;
    cout << "       直线检测与角度测量结果" << endl;
    cout << "========================================" << endl;

    for (size_t i = 0; i < labels.size(); i++)
    {
        char lbl = labels[i].first;
        int idx = labels[i].second;
        double rel = shortAngle(merged[idx].angle, refAngle);
        cout << "  角 A-P-" << lbl << " = " << (int)round(rel) << " 度" << endl;
    }

    cout << "\n  两两夹角:" << endl;
    for (size_t i = 0; i < labels.size(); i++)
    {
        for (size_t j = i + 1; j < labels.size(); j++)
        {
            double a = shortAngle(merged[labels[i].second].angle,
                                  merged[labels[j].second].angle);
            cout << "    " << labels[i].first << "-P-"
                 << labels[j].first << " = "
                 << (int)round(a) << "°" << endl;
        }
    }

    // ---------- 9. 在图像上标注 ----------
    Scalar palette[] = {
        Scalar(0, 0, 255),   // A - 红
        Scalar(200, 100, 0), // B - 蓝
        Scalar(0, 160, 0),   // C - 绿
        Scalar(180, 0, 180), // D - 紫
        Scalar(0, 160, 160)  // E - 黄
    };

    // 中心点 P
    circle(result, center, 6, Scalar(0, 0, 255), -1);
    putText(result, "P",
            Point(int(center.x) + 10, int(center.y) - 10),
            FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 255), 2);

    for (size_t i = 0; i < labels.size(); i++)
    {
        char lbl = labels[i].first;
        int idx = labels[i].second;
        Scalar c = palette[i % 5];

        Point2f ep = merged[idx].endpoint;
        Point2f dir = ep - center;
        double len = norm(dir);
        Point2f unitDir = dir / len;

        // --- 绘制射线 ---
        line(result, center, ep, c, 2);

        // --- 端点标签（A, B, C, D, E）---
        Point2f labelPos = ep + unitDir * 18;
        putText(result, string(1, lbl), labelPos,
                FONT_HERSHEY_SIMPLEX, 0.7, c, 2);

        // --- 角度标注（放在射线中段，偏上方）---
        double rel = shortAngle(merged[idx].angle, refAngle);
        Point2f midPoint = center + unitDir * (len * 0.55);

        // 根据射线方向调整偏移，避免文字被线遮挡
        Point2f perp(-unitDir.y, unitDir.x); // 垂直于射线方向
        Point2f offset = perp * 18;          // 偏移18像素
        // 如果射线朝右，向上偏；朝左，也向上偏（统一偏上）
        if (offset.y > 0)
            offset = -offset;

        string angText = "A-P-" + string(1, lbl) + ": " + to_string((int)round(rel));
        putText(result, angText, midPoint + offset,
                FONT_HERSHEY_SIMPLEX, 0.45, Scalar(0, 128, 0), 1, LINE_AA);
    }

    namedWindow("Result", WINDOW_NORMAL);
    imshow("Result", result);
    waitKey(0);
    destroyAllWindows();

    return 0;
}
